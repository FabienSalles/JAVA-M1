/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package td0.airline.management.system.exception;

/**
 *
 * @author fasalles
 */
public class FieldLengthException extends Exception
{
    /**
     * Constructor
     * @param message 
     */
    public FieldLengthException(String message)
    {
        super(message);
    }
}
